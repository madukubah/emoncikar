<form action="" method="GET" >
    <div class="row mb-2 ">
        <div class="col-3">
            <?= $form ?>
        </div>
        <div class="col-4" style="margin-top:3px">
            <button type="submit" class="btn btn-primary btn-sm"  style="margin-left: 5px;">
                ok
            </button>
        </div>
    </div>
</form>