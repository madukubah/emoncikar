<nav class="main-header navbar navbar-expand navbar-light navbar-white">
    <div class="container">
        <a href="<?= base_url() ?>" class="navbar-brand">
            <img src="<?= base_url() . ICON_IMAGE ?>" alt="Coreigniter Logo" class="brand-image" style="opacity: .8">
            <span class="brand-text font-weight-light"><?= APP_NAME ?></span>
        </a>