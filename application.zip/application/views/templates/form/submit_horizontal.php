<?= form_open()?>
    <div class="row mb-2 ">
        <div class="col">
            <?= $form ?>
        </div>
        <div class="col-4" style="margin-top:3px">
            <button type="submit" class="btn btn-primary btn-sm"  style="margin-left: 5px;">
                Kirim
            </button>
        </div>
    </div>
</form>