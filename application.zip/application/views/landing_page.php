<!-- Promo Block -->
  <div class="col-md-12" style="height:100vh; background: #f15f79;
      background: linear-gradient(to bottom, #f15f79 0%,#b24592 100%);">
      <div class="content" style="color:white;padding-top:200px; text-align:center">
        <h1>Welcome To <?= APP_NAME?>!</h1>
      </div>
  </div>
<!-- End Promo Block -->
