export declare const allStringsOfArray1InArray2: (arr1: string[], arr2: string[]) => boolean;
